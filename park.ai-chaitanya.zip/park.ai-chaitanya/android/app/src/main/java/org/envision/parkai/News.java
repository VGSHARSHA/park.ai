package org.envision.parkai;

/**
 * Created by root on 10/3/19.
 */

public class News {

   /* private String title;
    private String desc;
    private String image;
    private String url;
    private String time;

    public News(String title, String desc, String image, String url,String time) {
        this.title = title;
        this.desc = desc;
        this.image = image;
        this.url = url;
        this.time=time;
    }

    public News(){

    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }


    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }



    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }



    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
} */
private String hostuid;
 private String name;
    private String address;
    private String phone;
    private String charge;
    private String image;
    private String status;

    public News(String hostuid,String name, String address, String phone, String charge, String image,String status) {
        this.hostuid=hostuid;
        this.name = name;
        this.address = address;
        this.phone = phone;
        this.charge = charge;
        this.image = image;
        this.status=status;
    }

    public News(){

    }

    public String getHostuid() {
        return hostuid;
    }

    public void setHostuid(String hostuid) {
        this.hostuid = hostuid;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getCharge() {
        return charge;
    }

    public void setCharge(String charge) {
        this.charge = charge;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
    }
